<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return User::get();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user = new User();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = $request->password;
        $user->save();
        return response()->json(['sms', 'Create Successfully !']);
    }

    public function getUsersPostComments()
    {
        return User::with(['post', 'post.comment'])->get();
    }
    public function getUsersPostCommentsLikes()
    {
        return User::with(['post', 'post.comment', 'post.like'])->get();
    }
    public function getOneUsersPostCommentsLikes($id)
    {
        return User::with(['post', 'post.comment', 'post.like'])->where('id', $id)->get();
    }

    public function getUsersCountPostsComments()
    {
        return User::withCount(['post', 'comment'])->get();
    }

}
